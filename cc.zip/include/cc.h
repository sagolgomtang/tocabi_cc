#include "tocabi_lib/robot_data.h"
#include "wholebody_functions.h"
#include <random>
#include <cmath>

#include <ros/ros.h>
#include <sensor_msgs/Joy.h>
#include <std_msgs/String.h>
#include <std_msgs/Float32MultiArray.h>
#include <std_msgs/Float32.h>
#include <std_msgs/Empty.h>
#include <visualization_msgs/Marker.h>
#include <tocabi_msgs/TaskCommand.h>
#include <tocabi_msgs/positionCommand.h>

#include "onnxruntime_cxx_api.h"
#include <urdf/model.h>
#include <array>
#include <string>
#include <vector>

class CustomController
{
public:
    CustomController(RobotData &rd);
    Eigen::VectorQd getControl();

    //void taskCommandToCC(TaskCommand tc_);
    
    void computeSlow();
    void computeFast();
    void computePlanner();
    void copyRobotData(RobotData &rd_l);

    RobotData &rd_;
    RobotData rd_cc_;

    void loadOnnX();
    void loadJointLimits();
    void processNoise();
    void processObservation();
    void processDiscriminator();
    void feedforwardPolicy();
    void initVariable();
    void publishCommandMarker();
    void publishCommandVector();
    void updatePace();
    
    void quatToTanNorm(const Eigen::Quaterniond& quaternion, Eigen::Vector3d& tangent, Eigen::Vector3d& normal);
    Eigen::Vector3d mat2euler(Eigen::Matrix3d mat);
    Eigen::Vector3d quatRotateInverse(const Eigen::Quaterniond& q, const Eigen::Vector3d& v);


    /////////////////////////////////// ONNX Runtime by Yongarry ///////////////////////////////////////
    size_t input_number, output_number;
    std::vector<std::string> input_names, output_names;
    std::vector<const char *> input_names_char, output_names_char;
    std::vector<Ort::Value> input_tensors, output_tensors;

    std::vector<std::vector<float>> input_states_buffer;
    std::vector<float> state_cur_, state_buffer_;

    // for long history observation
    std::vector<float> state_long_hist_, state_long_hist_buffer_;

    int input_obs_idx_ = 0;

    ///////////////////////////////////// Actor-Critic Network ///////////////////////////////////////
    static const int num_action = 12;
    static const int num_actuator_action = 12;
    // static const int num_cur_state = 49; // 37 + 12
    // LegActor obs: 54 total, 42 internal (excluding last action)
    static const int num_cur_state = 54;
    static const int num_cur_internal_state = 42;
    static const int num_state_skip = 2;
    // static const int num_state_skip = 1;
    static const int num_state_hist = 10;
    // static const int num_state_hist = 1;
    static const int num_state = num_cur_internal_state*num_state_hist+num_action*(num_state_hist-1);
    // static const int num_state = num_cur_internal_state +num_action;

    // for long history observation
    static const int num_long_hist_skip = 10;
    static const int num_long_hist_len = 50;
    static const int num_hist_state = num_long_hist_len * num_long_hist_skip;


    Eigen::MatrixXd rl_action_, rl_action_pre_, torq_diff_, energy;
    double value_;
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    bool stop_by_value_thres_ = false;
    bool enable_value_stop_ = false;
    Eigen::Matrix<double, MODEL_DOF, 1> q_stop_;
    float stop_start_time_;

    std::ofstream writeFile;

    bool is_on_robot_ = false;
    bool is_write_file_ = true;
    bool is_hist_encoder_ = false;

    Eigen::Matrix<double, MODEL_DOF, 1> q_dot_lpf_;

    Eigen::Matrix<double, MODEL_DOF, 1> q_init_;
    Eigen::Matrix<double, MODEL_DOF, 1> q_init_mode7_;
    Eigen::Matrix<double, MODEL_DOF, 1> q_noise_;
    Eigen::Matrix<double, MODEL_DOF, 1> q_noise_pre_;
    Eigen::Matrix<double, MODEL_DOF, 1> q_vel_noise_, q_vel_noise_pre_;

    Eigen::Matrix<double, MODEL_DOF, 1> torque_init_;
    Eigen::Matrix<double, MODEL_DOF, 1> torque_spline_;
    Eigen::Matrix<double, MODEL_DOF, 1> torque_rl_;
    Eigen::Matrix<double, MODEL_DOF, 1> torque_bound_;

    Eigen::Matrix<double, MODEL_DOF, MODEL_DOF> kp_;
    Eigen::Matrix<double, MODEL_DOF, MODEL_DOF> kv_;

    Eigen::VectorQd Gravity_MJ_;

    Eigen::Vector6d LF_CF_FT_pre, RF_CF_FT_pre = Eigen::Vector6d::Zero();

    float start_time_;
    float time_inference_pre_ = 0.0;
    float time_write_pre_ = 0.0;

    double time_cur_;
    double time_pre_;

    Eigen::Vector3d euler_angle_;
    Eigen::Vector3d tan_vec, nor_vec;

    // float ft_left_init_ = 500.0;
    // float ft_right_init_ = 500.0;

    string weight_dir_ = "";
    // Joystick
    ros::NodeHandle nh_;

    void joyCallback(const sensor_msgs::Joy::ConstPtr& joy);
    void xBoxJoyCallback(const sensor_msgs::Joy::ConstPtr& joy);
    void simTimeCallback(const std_msgs::Float32ConstPtr& msg);
    ros::Subscriber joy_sub_;
    ros::Subscriber xbox_joy_sub_;
    ros::Publisher sim_command_pub_;
    ros::Subscriber sim_time_sub_;
    ros::Publisher cmd_marker_pub_;
    ros::Publisher cmd_vec_pub_;
    ros::Publisher cam_cmd_pub_;
    ros::Publisher gui_send_pub_;
    ros::Subscriber gui_send_sub_;
    ros::Publisher task_cmd_pub_;
    ros::Publisher pos_cmd_pub_;
    bool prev_btn9_ = false;
    bool prev_btn0_ = false;
    bool prev_btn10_ = false;
    bool prev_btn1_ = false;
    bool prev_btn8_ = false;
    void guiSendCallback(const std_msgs::Empty::ConstPtr& msg);
    double cmd_vis_scale_ = 1.0;

    Eigen::Vector3d local_lin_vel_;

    Eigen::Matrix<double, 12, 12> action_offset_, 
                                  action_scale_;
    double target_vel_x_ = 0.0;
    double target_vel_y_ = 0.0;
    double target_vel_yaw_ = 0.0;

    float desired_vel_x = 0.0;
    float desired_vel_yaw = 0.0;
    bool value_valid_ = false;
    double phase_period_s_ = 1.2;
    double phase_offset_s_ = 0.0;
    bool phase_started_ = false;
    double phase_start_time_s_ = 0.0;
    double phase_time_s_ = 0.0;
    int64_t phase_last_update_us_ = 0;
    bool sim_paused_ = false;
    ros::Time last_sim_time_msg_;
    bool sim_time_received_ = false;
    double sim_time_s_ = 0.0;
    double sim_time_prev_s_ = 0.0;
    double cmd_scale_x_ = 1.0;
    double cmd_scale_y_ = 0.5;
    double cmd_scale_yaw_ = 0.6;

    bool pace_trigger_ = false;
    bool pace_active_ = false;
    double pace_start_time_s_ = 0.0;
    double pace_last_pub_time_s_ = 0.0;
    double pace_duration_s_ = 10.0;
    double pace_min_freq_ = 0.1;
    double pace_max_freq_ = 10.0;
    Eigen::Matrix<double, 12, 1> pace_direction_;
    Eigen::Matrix<double, 12, 1> pace_bias_;
    Eigen::Matrix<double, 12, 1> pace_scale_;
    Eigen::VectorQd pace_hold_q_;
    std::vector<double> pace_pos_kp_backup_;
    std::vector<double> pace_pos_kv_backup_;
    bool pace_gains_saved_ = false;
    bool pace_align_active_ = false;
    double pace_align_start_s_ = 0.0;
    double pace_align_duration_s_ = 2.0;
    double pace_align_gain_ = 3.0;
    bool pace_hold_after_ = true;
    bool pace_collect_enabled_ = false;
    bool pace_collect_saved_ = false;
    double pace_collect_start_time_s_ = 0.0;
    std::string pace_collect_output_dir_ = "/home/user/other_ws/src/pace-sim2real/data/tocabi_mujoco";
    std::string pace_collect_output_prefix_ = "chirp_data";
    std::vector<double> pace_collect_time_;
    std::vector<Eigen::VectorQd> pace_collect_q_;
    std::vector<Eigen::VectorQd> pace_collect_des_;
    bool pace_pc_gravity_saved_ = false;
    bool pace_pc_gravity_backup_ = true;
    bool pace_has_prev_des_ = false;
    Eigen::VectorQd pace_prev_des_;

    Eigen::VectorQd q_min_;
    Eigen::VectorQd q_max_;
    bool has_joint_limits_ = false;
    double q_limit_scale_ = 1.0;
    int debug_log_steps_remaining_ = 0;
    bool debug_log_this_step_ = false;
    bool mode7_active_ = false;
    bool mode6_active_ = false;
    bool mode6_done_ = false;
    int prev_tc_mode_ = -1;
    bool mode6_logged_ = false;
    bool mode7_send_triggered_ = false;
    size_t test_log_step_ = 0;
    std::string test_log_dir_ = "/home/user/tocabi_mujoco_ws/src/tocabi_cc/test_log";
    std::ofstream test_obs_file_;
    std::ofstream test_act_file_;
    std::ofstream test_act_mapped_file_;
    std::vector<Eigen::Matrix<double, 12, 1>> test_act_buffer_;
    std::string test_act_runtime_name_ = "leg_actions_sim.txt";
    std::string test_act_mapped_name_ = "leg_actions_sim_mapped.txt";
    std::string test_obs_input_name_ = "leg_actor_obs.txt";
    std::vector<std::vector<float>> test_obs_buffer_;
    size_t test_obs_idx_ = 0;
    size_t test_max_steps_ = 0;
    std::ofstream test_obs_sim_file_;
    std::string test_obs_sim_name_ = "leg_actor_obs_sim.txt";
    size_t test_obs_sim_step_ = 0;
    bool test_obs_sim_done_ = false;
    size_t test_obs_sim_max_steps_ = 1000;

private:
    Eigen::VectorQd ControlVal_;

    Ort::Env env;
    Ort::Session session;
    Ort::MemoryInfo memory_info;

    const std::string reset = "\033[0m";     // Reset color
    const std::string red = "\033[31m";     // Red
    const std::string green = "\033[32m";   // Green
    const std::string yellow = "\033[33m";  // Yellow
    const std::string blue = "\033[34m"; 
};
